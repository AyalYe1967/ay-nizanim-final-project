create_iam_roles = false

external_execution_role_arn = "arn:aws:iam::992382545251:role/ay-l-final-project-ecs-execution-role-manual"
external_task_role_arn      = "arn:aws:iam::992382545251:role/ay-l-final-project-ecs-task-role-manual"